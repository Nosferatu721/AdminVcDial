module.exports = {
  database: {
    host: 'localhost',
    user: 'cos_crm',
    password: 'gestiongeneralcos:2020',
    database: 'dbp_usuarios'
  }
}
